// src/clipper.ts
function extractPageContent() {
  const TRACKING_PARAMS = [
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_term",
    "utm_content",
    "utm_id",
    "fbclid",
    "gclid",
    "gclsrc",
    "dclid",
    "msclkid",
    "twclid",
    "ttclid",
    "mc_cid",
    "mc_eid",
    "si",
    "ref",
    "ref_src",
    "ref_url",
    "_hsenc",
    "_hsmi",
    "wickedid",
    "igshid",
    "srsltid",
    "yclid"
  ];
  const TRACKER_DOMAINS = [
    "google-analytics.com",
    "googletagmanager.com",
    "doubleclick.net",
    "facebook.com/tr",
    "facebook.net",
    "connect.facebook.net",
    "pixel.facebook.com",
    "analytics.twitter.com",
    "segment.com",
    "segment.io",
    "hotjar.com",
    "datadoghq-browser-agent.com",
    "criteo.com",
    "taboola.com",
    "outbrain.com",
    "clarity.ms",
    "mixpanel.com",
    "amplitude.com",
    "scorecardresearch.com",
    "quantserve.com",
    "chartbeat.com",
    "parsely.com",
    "crazyegg.com",
    "intercom.io",
    "hubspot.com"
  ];
  function cleanUrl(urlStr, base = window.location.href) {
    if (!urlStr || urlStr.startsWith("#") || urlStr.startsWith("mailto:") || urlStr.startsWith("tel:") || urlStr.startsWith("javascript:")) {
      return { cleanedUrl: urlStr || "", purged: 0 };
    }
    try {
      const url = new URL(urlStr, base);
      let purged = 0;
      for (const param of TRACKING_PARAMS) {
        if (url.searchParams.has(param)) {
          url.searchParams.delete(param);
          purged++;
        }
      }
      for (const key of Array.from(url.searchParams.keys())) {
        if (key.startsWith("utm_") || key.startsWith("track_") || key.startsWith("analytics_")) {
          url.searchParams.delete(key);
          purged++;
        }
      }
      return { cleanedUrl: url.toString(), purged };
    } catch {
      return { cleanedUrl: urlStr, purged: 0 };
    }
  }
  try {
    const originalHtml = document.body ? document.body.innerHTML : "";
    const originalByteSize = new Blob([originalHtml]).size;
    let scriptsPurged = 0;
    let trackingPixelsPurged = 0;
    let trackingParamsPurged = 0;
    let inlineHandlersPurged = 0;
    let surveillanceElementsPurged = 0;
    const purgedTrackersSummary = [];
    let jsonLdAuthor = "";
    let jsonLdTitle = "";
    let jsonLdDate = "";
    let jsonLdExcerpt = "";
    const jsonLdTags = [];
    const ldScripts = document.querySelectorAll('script[type="application/ld+json"]');
    ldScripts.forEach((script) => {
      try {
        const rawJson = script.textContent ? JSON.parse(script.textContent) : null;
        if (!rawJson) return;
        const items = Array.isArray(rawJson) ? rawJson : rawJson["@graph"] && Array.isArray(rawJson["@graph"]) ? rawJson["@graph"] : [rawJson];
        for (const item of items) {
          if (item["@type"] && /Article|Posting|Report|Story|News|Blog|WebPage/i.test(String(item["@type"]))) {
            if (item.headline && !jsonLdTitle) jsonLdTitle = String(item.headline).trim();
            if (item.name && !jsonLdTitle) jsonLdTitle = String(item.name).trim();
            if (item.datePublished && !jsonLdDate) jsonLdDate = String(item.datePublished).trim();
            if (item.description && !jsonLdExcerpt) jsonLdExcerpt = String(item.description).trim();
            if (item.author && !jsonLdAuthor) {
              if (typeof item.author === "string") {
                jsonLdAuthor = item.author.trim();
              } else if (Array.isArray(item.author) && item.author[0]?.name) {
                jsonLdAuthor = String(item.author[0].name).trim();
              } else if (item.author.name) {
                jsonLdAuthor = String(item.author.name).trim();
              }
            }
            if (item.keywords) {
              const kw = Array.isArray(item.keywords) ? item.keywords : String(item.keywords).split(",");
              kw.forEach((k) => {
                const cleanK = String(k).trim();
                if (cleanK && cleanK.length < 30 && !jsonLdTags.includes(cleanK)) {
                  jsonLdTags.push(cleanK);
                }
              });
            }
          }
        }
      } catch {
      }
    });
    const ogTitle = document.querySelector('meta[property="og:title"]')?.getAttribute("content");
    const twitterTitle = document.querySelector('meta[name="twitter:title"]')?.getAttribute("content");
    const docTitle = document.title || "";
    let rawTitle = jsonLdTitle || ogTitle || twitterTitle || "";
    if (!rawTitle) {
      const firstH1 = document.querySelector("h1");
      rawTitle = firstH1?.textContent?.trim() || docTitle || "Untitled Article";
    }
    let title = rawTitle.replace(/\s*[|\-–—]\s*(?:by\s+[^|\-–—]+|Gates Notes|Medium|Substack|The Verge|TechCrunch|Wired|Reuters|Bloomberg|Ars Technica|The New York Times|BBC News|The Guardian).*$/i, "").replace(/\s*[|\-–—]\s*[^|\-–—]+$/, "").trim() || rawTitle;
    const ogAuthor = document.querySelector('meta[name="author"]')?.getAttribute("content") || document.querySelector('meta[property="article:author"]')?.getAttribute("content") || document.querySelector('meta[name="twitter:creator"]')?.getAttribute("content") || document.querySelector('.ArtAuthName, [class*="author-name" i], [class*="byline" i], [rel="author"], [data-testid="authorName"]')?.textContent?.trim() || "";
    const titleAuthorMatch = rawTitle.match(/(?:by|author:?)\s+([^|\-–—]+)/i);
    const titleAuthor = titleAuthorMatch ? titleAuthorMatch[1].trim() : "";
    const author = jsonLdAuthor || (ogAuthor ? ogAuthor.replace(/^by\s+/i, "").trim() : "") || titleAuthor || window.location.hostname.replace("www.", "");
    const ogDesc = document.querySelector('meta[property="og:description"]')?.getAttribute("content") || document.querySelector('meta[name="description"]')?.getAttribute("content") || document.querySelector('meta[name="twitter:description"]')?.getAttribute("content") || document.querySelector('.ArtDesc, .subtitle, .summary, [class*="lead" i]')?.textContent?.trim() || jsonLdExcerpt || "";
    const excerpt = ogDesc.trim();
    const canonicalTag = document.querySelector('link[rel="canonical"]')?.getAttribute("href");
    const { cleanedUrl: canonicalUrl } = cleanUrl(canonicalTag || window.location.href);
    const pubDate = jsonLdDate || document.querySelector('meta[property="article:published_time"]')?.getAttribute("content") || document.querySelector("time[datetime]")?.getAttribute("datetime") || document.querySelector("time")?.textContent?.trim() || (/* @__PURE__ */ new Date()).toISOString();
    const siteName = document.querySelector('meta[property="og:site_name"]')?.getAttribute("content") || window.location.hostname.replace("www.", "");
    const metaKeywords = document.querySelector('meta[name="keywords"]')?.getAttribute("content") || "";
    const tags = Array.from(
      /* @__PURE__ */ new Set([
        ...jsonLdTags,
        ...metaKeywords ? metaKeywords.split(",").map((t) => t.trim()).filter(Boolean) : []
      ])
    );
    document.querySelectorAll('a[href*="/tag/"], a[href*="/category/"], a[href*="/topic/"]').forEach((el) => {
      const text = el.textContent?.replace(/^#/, "").trim();
      if (text && text.length < 25 && !tags.includes(text)) {
        tags.push(text);
      }
    });
    const currentPath = window.location.pathname;
    const urlSlugMatch = currentPath.match(/\/([^\/?#]+)$/);
    const urlSlug = urlSlugMatch ? urlSlugMatch[1].toLowerCase() : "";
    const urlSlugUnderscore = urlSlug.replace(/-/g, "_");
    let scopedRoot = null;
    if (urlSlug && urlSlug.length > 3) {
      const slugElement = document.querySelector(
        `[id*="${urlSlug}" i], [id*="${urlSlugUnderscore}" i], [class*="${urlSlug}" i]`
      );
      if (slugElement) {
        const candidateParent = slugElement.closest(
          'article, section, .ReaderShift, [class*="chapter" i], [class*="article" i]'
        );
        scopedRoot = candidateParent || slugElement;
      }
    }
    const searchScope = scopedRoot || document.body;
    const allH1s = Array.from(searchScope.querySelectorAll("h1"));
    let targetH1 = null;
    if (allH1s.length === 1) {
      targetH1 = allH1s[0];
    } else if (allH1s.length > 1) {
      let bestH1Score = -1;
      const normTitleWords = title.toLowerCase().replace(/[^a-z0-9\s]/g, "").split(/\s+/).filter(Boolean);
      allH1s.forEach((h1) => {
        const text = (h1.textContent || "").toLowerCase().replace(/[^a-z0-9\s]/g, "");
        let score = 0;
        normTitleWords.forEach((word) => {
          if (word.length > 2 && text.includes(word)) score += 10;
        });
        if (urlSlug && text.includes(urlSlug.replace(/[-_]/g, " "))) score += 25;
        if (score > bestH1Score) {
          bestH1Score = score;
          targetH1 = h1;
        }
      });
    }
    let bestContainer = null;
    const prioritySelectors = [
      ".ArtBody",
      '[class*="ArtBody" i]',
      ".article-body",
      '[class*="article-body" i]',
      ".post-content",
      '[class*="post-content" i]',
      ".entry-content",
      '[class*="entry-content" i]',
      ".story-content",
      '[class*="story-content" i]',
      ".gh-content",
      ".available-content",
      ".markup--post-full",
      ".caas-body",
      ".articleHolder",
      "article",
      '[role="main"] article',
      "main article",
      '[role="main"]',
      "main",
      "#article-body",
      "#content"
    ];
    let maxScore = 0;
    for (const sel of prioritySelectors) {
      const candidates = searchScope.querySelectorAll(sel);
      candidates.forEach((el) => {
        if (el.closest("header, nav, footer, aside, .siteHeader, .expandedMenu, .CommentsHolder, #CommentsHolder")) {
          return;
        }
        const paragraphs = el.querySelectorAll("p");
        let pTextLen = 0;
        paragraphs.forEach((p) => {
          pTextLen += (p.textContent || "").trim().length;
        });
        const links = el.querySelectorAll("a");
        let linkTextLen = 0;
        links.forEach((a) => {
          linkTextLen += (a.textContent || "").trim().length;
        });
        const linkDensity = pTextLen > 0 ? linkTextLen / pTextLen : 1;
        if (linkDensity > 0.35) return;
        const score = paragraphs.length * 20 + Math.min(pTextLen / 20, 800) - linkDensity * 300;
        if (score > maxScore) {
          maxScore = score;
          bestContainer = el;
        }
      });
      if (bestContainer && maxScore >= 200) break;
    }
    if (!bestContainer && targetH1) {
      let curr = targetH1.parentElement;
      while (curr && curr !== document.body && curr !== searchScope) {
        const pCount = curr.querySelectorAll("p").length;
        if (pCount >= 3) {
          bestContainer = curr;
          break;
        }
        curr = curr.parentElement;
      }
    }
    const sourceNode = bestContainer || searchScope || document.body;
    const clone = sourceNode.cloneNode(true);
    clone.querySelectorAll('[id^="reader_"], .ReaderShift, [class*="next-story" i], [class*="infinite-scroll" i], [class*="post-preview" i]').forEach((sibling) => {
      if (sibling !== clone) {
        sibling.remove();
        surveillanceElementsPurged++;
      }
    });
    clone.querySelectorAll('.ArticleQuoteHolder, [class*="quote-holder" i], [class*="pullquote" i]').forEach((holder) => {
      const quoteBody = holder.querySelector(".ArticleQuoteBody, p, blockquote");
      const text = quoteBody?.textContent?.trim() || holder.textContent?.trim() || "";
      if (text) {
        const bq = document.createElement("blockquote");
        bq.innerHTML = `<p>${text}</p>`;
        holder.replaceWith(bq);
      } else {
        holder.remove();
      }
    });
    clone.querySelectorAll('.NoteItem, [class*="callout" i], [class*="note-box" i]').forEach((box) => {
      const titleEl = box.querySelector('.NoteItemTitle, [class*="title" i], [class*="heading" i]');
      const eyebrowEl = box.querySelector('.NoteItemEyebrow, [class*="eyebrow" i]');
      const titleText = titleEl?.textContent?.trim() || "";
      const eyebrowText = eyebrowEl?.textContent?.trim() || "";
      const bodyText = box.textContent?.trim() || "";
      if (titleText || eyebrowText) {
        const bq = document.createElement("blockquote");
        const heading = eyebrowText ? `<strong>${eyebrowText}</strong>: ` : "";
        bq.innerHTML = `<p>${heading}${titleText || bodyText}</p>`;
        box.replaceWith(bq);
      }
    });
    const removeElements = (selector, reason) => {
      clone.querySelectorAll(selector).forEach((el) => {
        const elTextLen = (el.textContent || "").length;
        const totalLen = (clone.textContent || "").length;
        if (totalLen > 0 && elTextLen / totalLen > 0.6) return;
        el.remove();
        surveillanceElementsPurged++;
        if (purgedTrackersSummary.length < 10 && !purgedTrackersSummary.includes(reason)) {
          purgedTrackersSummary.push(reason);
        }
      });
    };
    clone.querySelectorAll("script, noscript, style, link[rel='stylesheet']").forEach((el) => {
      el.remove();
      scriptsPurged++;
    });
    if (scriptsPurged > 0) {
      purgedTrackersSummary.push(`Active Scripts & CSS Overlays (${scriptsPurged})`);
    }
    removeElements(
      "nav, header, footer, aside, form, button, dialog, menu, select, textarea, input",
      "Page Nav & Interactive Modals"
    );
    removeElements(
      ".siteHeader, .siteHeaderInner, .siteHeaderExpandedDesktop, .siteHeaderExpandedMobile, .expandedMenus, .expandedMenu, .SiteSections, [class*='siteHeader'], [class*='site-header'], [class*='navbar'], [class*='nav-menu'], [class*='drawer']",
      "Site Headers & Navigation Drawers"
    );
    removeElements(
      "#CommentsHolder, .CommentsHolder, .CommentsHolderBottomContent, .threaded-comments, [class*='comment-box'], [class*='comments-section'], [id*='disqus'], [class*='disqus']",
      "Comments & Discussion Overlays"
    );
    removeElements(
      ".inlineVideoHolder, .LI_VideoHolder, .LI_VideoIcons, .lightBoxControls, .lightBoxProgress, .lightBoxCenter, .lightBoxFullscreen, .lightBoxCaptions, .lightBoxVolume, .video-modal-overlay, [class*='lightbox'], [class*='video-controls'], c4d-video-cta-container, c4d-lightbox-video-player-container",
      "Interactive Video Player Controls & Overlays"
    );
    removeElements(
      "#truste_consent_track, #truste_domain_list, #consent_blackbar, [id*='trustarc'], [id*='onetrust'], [class*='cookie-banner'], [id*='cookie-banner'], [class*='consent-modal'], #onetrust-consent-sdk, .cc-window, .didomi-popup-container, [id*='cookie'], [class*='cookie-consent']",
      "Cookie Consent & Tracking Banners"
    );
    removeElements(
      ".paywall, .subscription-widget-wrap, .newsletter-signup, .pencraft-dialog, .gate-container, [class*='paywall'], [id*='paywall'], [class*='subscribe-gate'], .tp-modal, .fc-ab-root, .MenuCardSU, .SignUpMenuButton, [class*='signup']",
      "Paywall & Newsletter Subscription Overlays"
    );
    removeElements(
      ".ad, .ads, .advertisement, .ad-banner, [id*='google_ads'], [class*='taboola'], [class*='outbrain'], .sponsored, .outbrain, .taboola",
      "Third-Party Ad Networks & Sponsored Links"
    );
    removeElements(
      ".Share-modal, .buttonShare, .primaryButton, .buttonComments, .articleEnd, .share-dialog, .post-ufi, .like-button, .clap-button, .social-share, [class*='share-modal'], [class*='share-button']",
      "Social Sharing & Interaction Buttons"
    );
    removeElements(
      ".ItemPlaceHolder, [id^='ph_'], .TopicTimelineSpacer, .ArticleTopSpacer, .ArticleSeperator, .htmlBlockHolder",
      "Empty Layout Placeholders & Spacers"
    );
    clone.querySelectorAll("iframe, object, embed").forEach((frame) => {
      const src = frame.getAttribute("src") || "";
      const isSafe = src.includes("youtube.com") || src.includes("youtube-nocookie.com") || src.includes("vimeo.com");
      if (!isSafe) {
        frame.remove();
        surveillanceElementsPurged++;
        if (!purgedTrackersSummary.includes("Tracking iFrames")) {
          purgedTrackersSummary.push("Tracking iFrames");
        }
      }
    });
    clone.querySelectorAll("svg").forEach((svg) => {
      svg.remove();
      surveillanceElementsPurged++;
    });
    clone.querySelectorAll("img").forEach((img) => {
      const src = img.getAttribute("src") || "";
      const alt = (img.getAttribute("alt") || "").toLowerCase();
      const cls = (img.className || "").toLowerCase();
      const width = parseInt(img.getAttribute("width") || "100", 10);
      const height = parseInt(img.getAttribute("height") || "100", 10);
      const isIconPattern = /\b(icon|logo|avatar|close|arrow|play|pause|check|quote|search|hamburger|menu|share|comment|btn|button|dot)\b/i;
      const isSvgFile = /\.svg(?:\?|$)/i.test(src);
      const isTiny = width > 0 && width <= 64 || height > 0 && height <= 64;
      const isPixel = width <= 1 || height <= 1;
      const isTrackerDomain = TRACKER_DOMAINS.some((d) => src.includes(d));
      const isBeacon = /\/(tr|collect|pixel|beacon|telemetry|track|event)\b/i.test(src);
      if (isPixel || isTrackerDomain || isBeacon) {
        img.remove();
        trackingPixelsPurged++;
        if (!purgedTrackersSummary.includes("Invisible Tracking Pixels")) {
          purgedTrackersSummary.push("Invisible Tracking Pixels");
        }
      } else if (isSvgFile || isIconPattern.test(cls) || isIconPattern.test(alt) || isIconPattern.test(src) || isTiny) {
        img.remove();
        surveillanceElementsPurged++;
      } else {
        const { cleanedUrl, purged } = cleanUrl(src);
        img.setAttribute("src", cleanedUrl);
        trackingParamsPurged += purged;
        img.setAttribute("loading", "lazy");
        img.setAttribute("decoding", "async");
        img.removeAttribute("srcset");
        img.removeAttribute("sizes");
        img.removeAttribute("data-nimg");
      }
    });
    clone.querySelectorAll("*").forEach((el) => {
      if (el.hasAttribute("style")) {
        el.removeAttribute("style");
      }
      const attrs = Array.from(el.attributes);
      for (const attr of attrs) {
        const name = attr.name.toLowerCase();
        if (name.startsWith("on")) {
          el.removeAttribute(attr.name);
          inlineHandlersPurged++;
        } else if (name.startsWith("data-track") || name.startsWith("data-analytics") || name.startsWith("data-ga") || name.startsWith("data-amplitude") || name.startsWith("data-nimg") || name.startsWith("data-artid") || name.startsWith("data-shown") || name === "ping") {
          el.removeAttribute(attr.name);
          surveillanceElementsPurged++;
        }
      }
    });
    clone.querySelectorAll("a").forEach((a) => {
      const href = a.getAttribute("href") || "";
      if (href) {
        const { cleanedUrl, purged } = cleanUrl(href);
        a.setAttribute("href", cleanedUrl);
        trackingParamsPurged += purged;
        a.setAttribute("rel", "noopener noreferrer");
        a.setAttribute("target", "_blank");
      }
    });
    clone.querySelectorAll("p, div, span, blockquote").forEach((el) => {
      if (el.children.length === 0 && !el.textContent?.trim()) {
        el.remove();
      }
    });
    const firstChildH1 = clone.querySelector("h1");
    if (firstChildH1) {
      const h1Text = (firstChildH1.textContent || "").trim().toLowerCase();
      const normTitle = title.trim().toLowerCase();
      if (h1Text === normTitle || normTitle.length > 5 && h1Text.includes(normTitle.slice(0, 20))) {
        firstChildH1.remove();
      }
    }
    const textContent = (clone.textContent || "").replace(/\s+/g, " ").trim();
    const wordCount = textContent ? textContent.split(/\s+/).filter(Boolean).length : 0;
    const readingTimeMinutes = Math.max(1, Math.ceil(wordCount / 200));
    const contentHtml = clone.innerHTML.trim();
    const cleanedByteSize = new Blob([contentHtml]).size;
    const totalPurged = scriptsPurged + trackingPixelsPurged + trackingParamsPurged + inlineHandlersPurged + surveillanceElementsPurged;
    const telemetry = {
      scriptsPurged,
      trackingPixelsPurged,
      trackingParamsPurged,
      inlineHandlersPurged,
      surveillanceElementsPurged,
      totalPurged,
      originalByteSize,
      cleanedByteSize,
      wordCount,
      readingTimeMinutes,
      purgedTrackersSummary
    };
    return {
      title,
      author,
      excerpt,
      contentHtml,
      textContent,
      canonicalUrl,
      publishedAt: pubDate,
      siteName,
      tags: tags.slice(0, 6),
      wordCount,
      readingTimeMinutes,
      telemetry
    };
  } catch (err2) {
    const fallbackTitle = document.querySelector("h1")?.textContent?.trim() || document.title || "Untitled Document";
    const fallbackText = (document.body ? document.body.innerText : "").trim();
    const words = fallbackText ? fallbackText.split(/\s+/).filter(Boolean).length : 0;
    return {
      title: fallbackTitle,
      author: window.location.hostname.replace("www.", ""),
      excerpt: fallbackText.slice(0, 200),
      contentHtml: `<article><h1>${fallbackTitle}</h1><p>${fallbackText.replace(/\n\n+/g, "</p><p>")}</p></article>`,
      textContent: fallbackText,
      canonicalUrl: window.location.href,
      publishedAt: (/* @__PURE__ */ new Date()).toISOString(),
      siteName: window.location.hostname.replace("www.", ""),
      tags: ["web-archive"],
      wordCount: words,
      readingTimeMinutes: Math.max(1, Math.ceil(words / 200)),
      telemetry: {
        scriptsPurged: 0,
        trackingPixelsPurged: 0,
        trackingParamsPurged: 0,
        inlineHandlersPurged: 0,
        surveillanceElementsPurged: 0,
        totalPurged: 0,
        originalByteSize: fallbackText.length,
        cleanedByteSize: fallbackText.length,
        wordCount: words,
        readingTimeMinutes: Math.max(1, Math.ceil(words / 200)),
        purgedTrackersSummary: ["Emergency Text Fallback"]
      }
    };
  }
}

// ../../node_modules/.pnpm/@noble+ed25519@2.3.0/node_modules/@noble/ed25519/index.js
var ed25519_CURVE = {
  p: 0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffedn,
  n: 0x1000000000000000000000000000000014def9dea2f79cd65812631a5cf5d3edn,
  h: 8n,
  a: 0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffecn,
  d: 0x52036cee2b6ffe738cc740797779e89800700a4d4141d8ab75eb4dca135978a3n,
  Gx: 0x216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51an,
  Gy: 0x6666666666666666666666666666666666666666666666666666666666666658n
};
var { p: P, n: N, Gx, Gy, a: _a, d: _d } = ed25519_CURVE;
var h = 8n;
var L = 32;
var L2 = 64;
var err = (m = "") => {
  throw new Error(m);
};
var isBig = (n) => typeof n === "bigint";
var isStr = (s) => typeof s === "string";
var isBytes = (a) => a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
var abytes = (a, l) => !isBytes(a) || typeof l === "number" && l > 0 && a.length !== l ? err("Uint8Array expected") : a;
var u8n = (len) => new Uint8Array(len);
var u8fr = (buf) => Uint8Array.from(buf);
var padh = (n, pad) => n.toString(16).padStart(pad, "0");
var bytesToHex = (b) => Array.from(abytes(b)).map((e) => padh(e, 2)).join("");
var C = { _0: 48, _9: 57, A: 65, F: 70, a: 97, f: 102 };
var _ch = (ch) => {
  if (ch >= C._0 && ch <= C._9)
    return ch - C._0;
  if (ch >= C.A && ch <= C.F)
    return ch - (C.A - 10);
  if (ch >= C.a && ch <= C.f)
    return ch - (C.a - 10);
  return;
};
var hexToBytes = (hex) => {
  const e = "hex invalid";
  if (!isStr(hex))
    return err(e);
  const hl = hex.length;
  const al = hl / 2;
  if (hl % 2)
    return err(e);
  const array = u8n(al);
  for (let ai = 0, hi = 0; ai < al; ai++, hi += 2) {
    const n1 = _ch(hex.charCodeAt(hi));
    const n2 = _ch(hex.charCodeAt(hi + 1));
    if (n1 === void 0 || n2 === void 0)
      return err(e);
    array[ai] = n1 * 16 + n2;
  }
  return array;
};
var toU8 = (a, len) => abytes(isStr(a) ? hexToBytes(a) : u8fr(abytes(a)), len);
var cr = () => globalThis?.crypto;
var subtle = () => cr()?.subtle ?? err("crypto.subtle must be defined");
var concatBytes = (...arrs) => {
  const r = u8n(arrs.reduce((sum, a) => sum + abytes(a).length, 0));
  let pad = 0;
  arrs.forEach((a) => {
    r.set(a, pad);
    pad += a.length;
  });
  return r;
};
var randomBytes = (len = L) => {
  const c = cr();
  return c.getRandomValues(u8n(len));
};
var big = BigInt;
var arange = (n, min, max, msg = "bad number: out of range") => isBig(n) && min <= n && n < max ? n : err(msg);
var M = (a, b = P) => {
  const r = a % b;
  return r >= 0n ? r : b + r;
};
var modN = (a) => M(a, N);
var invert = (num, md) => {
  if (num === 0n || md <= 0n)
    err("no inverse n=" + num + " mod=" + md);
  let a = M(num, md), b = md, x = 0n, y = 1n, u = 1n, v = 0n;
  while (a !== 0n) {
    const q = b / a, r = b % a;
    const m = x - u * q, n = y - v * q;
    b = a, a = r, x = u, y = v, u = m, v = n;
  }
  return b === 1n ? M(x, md) : err("no inverse");
};
var callHash = (name) => {
  const fn = etc[name];
  if (typeof fn !== "function")
    err("hashes." + name + " not set");
  return fn;
};
var apoint = (p) => p instanceof Point ? p : err("Point expected");
var B256 = 2n ** 256n;
var Point = class _Point {
  static BASE;
  static ZERO;
  ex;
  ey;
  ez;
  et;
  constructor(ex, ey, ez, et) {
    const max = B256;
    this.ex = arange(ex, 0n, max);
    this.ey = arange(ey, 0n, max);
    this.ez = arange(ez, 1n, max);
    this.et = arange(et, 0n, max);
    Object.freeze(this);
  }
  static fromAffine(p) {
    return new _Point(p.x, p.y, 1n, M(p.x * p.y));
  }
  /** RFC8032 5.1.3: Uint8Array to Point. */
  static fromBytes(hex, zip215 = false) {
    const d = _d;
    const normed = u8fr(abytes(hex, L));
    const lastByte = hex[31];
    normed[31] = lastByte & ~128;
    const y = bytesToNumLE(normed);
    const max = zip215 ? B256 : P;
    arange(y, 0n, max);
    const y2 = M(y * y);
    const u = M(y2 - 1n);
    const v = M(d * y2 + 1n);
    let { isValid, value: x } = uvRatio(u, v);
    if (!isValid)
      err("bad point: y not sqrt");
    const isXOdd = (x & 1n) === 1n;
    const isLastByteOdd = (lastByte & 128) !== 0;
    if (!zip215 && x === 0n && isLastByteOdd)
      err("bad point: x==0, isLastByteOdd");
    if (isLastByteOdd !== isXOdd)
      x = M(-x);
    return new _Point(x, y, 1n, M(x * y));
  }
  /** Checks if the point is valid and on-curve. */
  assertValidity() {
    const a = _a;
    const d = _d;
    const p = this;
    if (p.is0())
      throw new Error("bad point: ZERO");
    const { ex: X, ey: Y, ez: Z, et: T } = p;
    const X2 = M(X * X);
    const Y2 = M(Y * Y);
    const Z2 = M(Z * Z);
    const Z4 = M(Z2 * Z2);
    const aX2 = M(X2 * a);
    const left = M(Z2 * M(aX2 + Y2));
    const right = M(Z4 + M(d * M(X2 * Y2)));
    if (left !== right)
      throw new Error("bad point: equation left != right (1)");
    const XY = M(X * Y);
    const ZT = M(Z * T);
    if (XY !== ZT)
      throw new Error("bad point: equation left != right (2)");
    return this;
  }
  /** Equality check: compare points P&Q. */
  equals(other) {
    const { ex: X1, ey: Y1, ez: Z1 } = this;
    const { ex: X2, ey: Y2, ez: Z2 } = apoint(other);
    const X1Z2 = M(X1 * Z2);
    const X2Z1 = M(X2 * Z1);
    const Y1Z2 = M(Y1 * Z2);
    const Y2Z1 = M(Y2 * Z1);
    return X1Z2 === X2Z1 && Y1Z2 === Y2Z1;
  }
  is0() {
    return this.equals(I);
  }
  /** Flip point over y coordinate. */
  negate() {
    return new _Point(M(-this.ex), this.ey, this.ez, M(-this.et));
  }
  /** Point doubling. Complete formula. Cost: `4M + 4S + 1*a + 6add + 1*2`. */
  double() {
    const { ex: X1, ey: Y1, ez: Z1 } = this;
    const a = _a;
    const A = M(X1 * X1);
    const B = M(Y1 * Y1);
    const C2 = M(2n * M(Z1 * Z1));
    const D = M(a * A);
    const x1y1 = X1 + Y1;
    const E = M(M(x1y1 * x1y1) - A - B);
    const G2 = D + B;
    const F = G2 - C2;
    const H = D - B;
    const X3 = M(E * F);
    const Y3 = M(G2 * H);
    const T3 = M(E * H);
    const Z3 = M(F * G2);
    return new _Point(X3, Y3, Z3, T3);
  }
  /** Point addition. Complete formula. Cost: `8M + 1*k + 8add + 1*2`. */
  add(other) {
    const { ex: X1, ey: Y1, ez: Z1, et: T1 } = this;
    const { ex: X2, ey: Y2, ez: Z2, et: T2 } = apoint(other);
    const a = _a;
    const d = _d;
    const A = M(X1 * X2);
    const B = M(Y1 * Y2);
    const C2 = M(T1 * d * T2);
    const D = M(Z1 * Z2);
    const E = M((X1 + Y1) * (X2 + Y2) - A - B);
    const F = M(D - C2);
    const G2 = M(D + C2);
    const H = M(B - a * A);
    const X3 = M(E * F);
    const Y3 = M(G2 * H);
    const T3 = M(E * H);
    const Z3 = M(F * G2);
    return new _Point(X3, Y3, Z3, T3);
  }
  /**
   * Point-by-scalar multiplication. Scalar must be in range 1 <= n < CURVE.n.
   * Uses {@link wNAF} for base point.
   * Uses fake point to mitigate side-channel leakage.
   * @param n scalar by which point is multiplied
   * @param safe safe mode guards against timing attacks; unsafe mode is faster
   */
  multiply(n, safe = true) {
    if (!safe && (n === 0n || this.is0()))
      return I;
    arange(n, 1n, N);
    if (n === 1n)
      return this;
    if (this.equals(G))
      return wNAF(n).p;
    let p = I;
    let f = G;
    for (let d = this; n > 0n; d = d.double(), n >>= 1n) {
      if (n & 1n)
        p = p.add(d);
      else if (safe)
        f = f.add(d);
    }
    return p;
  }
  /** Convert point to 2d xy affine point. (X, Y, Z) ∋ (x=X/Z, y=Y/Z) */
  toAffine() {
    const { ex: x, ey: y, ez: z } = this;
    if (this.equals(I))
      return { x: 0n, y: 1n };
    const iz = invert(z, P);
    if (M(z * iz) !== 1n)
      err("invalid inverse");
    return { x: M(x * iz), y: M(y * iz) };
  }
  toBytes() {
    const { x, y } = this.assertValidity().toAffine();
    const b = numTo32bLE(y);
    b[31] |= x & 1n ? 128 : 0;
    return b;
  }
  toHex() {
    return bytesToHex(this.toBytes());
  }
  // encode to hex string
  clearCofactor() {
    return this.multiply(big(h), false);
  }
  isSmallOrder() {
    return this.clearCofactor().is0();
  }
  isTorsionFree() {
    let p = this.multiply(N / 2n, false).double();
    if (N % 2n)
      p = p.add(this);
    return p.is0();
  }
  static fromHex(hex, zip215) {
    return _Point.fromBytes(toU8(hex), zip215);
  }
  get x() {
    return this.toAffine().x;
  }
  get y() {
    return this.toAffine().y;
  }
  toRawBytes() {
    return this.toBytes();
  }
};
var G = new Point(Gx, Gy, 1n, M(Gx * Gy));
var I = new Point(0n, 1n, 1n, 0n);
Point.BASE = G;
Point.ZERO = I;
var numTo32bLE = (num) => hexToBytes(padh(arange(num, 0n, B256), L2)).reverse();
var bytesToNumLE = (b) => big("0x" + bytesToHex(u8fr(abytes(b)).reverse()));
var pow2 = (x, power) => {
  let r = x;
  while (power-- > 0n) {
    r *= r;
    r %= P;
  }
  return r;
};
var pow_2_252_3 = (x) => {
  const x2 = x * x % P;
  const b2 = x2 * x % P;
  const b4 = pow2(b2, 2n) * b2 % P;
  const b5 = pow2(b4, 1n) * x % P;
  const b10 = pow2(b5, 5n) * b5 % P;
  const b20 = pow2(b10, 10n) * b10 % P;
  const b40 = pow2(b20, 20n) * b20 % P;
  const b80 = pow2(b40, 40n) * b40 % P;
  const b160 = pow2(b80, 80n) * b80 % P;
  const b240 = pow2(b160, 80n) * b80 % P;
  const b250 = pow2(b240, 10n) * b10 % P;
  const pow_p_5_8 = pow2(b250, 2n) * x % P;
  return { pow_p_5_8, b2 };
};
var RM1 = 0x2b8324804fc1df0b2b4d00993dfbd7a72f431806ad2fe478c4ee1b274a0ea0b0n;
var uvRatio = (u, v) => {
  const v3 = M(v * v * v);
  const v7 = M(v3 * v3 * v);
  const pow = pow_2_252_3(u * v7).pow_p_5_8;
  let x = M(u * v3 * pow);
  const vx2 = M(v * x * x);
  const root1 = x;
  const root2 = M(x * RM1);
  const useRoot1 = vx2 === u;
  const useRoot2 = vx2 === M(-u);
  const noRoot = vx2 === M(-u * RM1);
  if (useRoot1)
    x = root1;
  if (useRoot2 || noRoot)
    x = root2;
  if ((M(x) & 1n) === 1n)
    x = M(-x);
  return { isValid: useRoot1 || useRoot2, value: x };
};
var modL_LE = (hash) => modN(bytesToNumLE(hash));
var sha512a = (...m) => etc.sha512Async(...m);
var sha512s = (...m) => callHash("sha512Sync")(...m);
var hash2extK = (hashed) => {
  const head = hashed.slice(0, L);
  head[0] &= 248;
  head[31] &= 127;
  head[31] |= 64;
  const prefix = hashed.slice(L, L2);
  const scalar = modL_LE(head);
  const point = G.multiply(scalar);
  const pointBytes = point.toBytes();
  return { head, prefix, scalar, point, pointBytes };
};
var getExtendedPublicKeyAsync = (priv) => sha512a(toU8(priv, L)).then(hash2extK);
var getExtendedPublicKey = (priv) => hash2extK(sha512s(toU8(priv, L)));
var getPublicKeyAsync = (priv) => getExtendedPublicKeyAsync(priv).then((p) => p.pointBytes);
var etc = {
  sha512Async: async (...messages) => {
    const s = subtle();
    const m = concatBytes(...messages);
    return u8n(await s.digest("SHA-512", m.buffer));
  },
  sha512Sync: void 0,
  bytesToHex,
  hexToBytes,
  concatBytes,
  mod: M,
  invert,
  randomBytes
};
var utils = {
  getExtendedPublicKeyAsync,
  getExtendedPublicKey,
  randomPrivateKey: () => randomBytes(L),
  precompute: (w = 8, p = G) => {
    p.multiply(3n);
    w;
    return p;
  }
  // no-op
};
var W = 8;
var scalarBits = 256;
var pwindows = Math.ceil(scalarBits / W) + 1;
var pwindowSize = 2 ** (W - 1);
var precompute = () => {
  const points = [];
  let p = G;
  let b = p;
  for (let w = 0; w < pwindows; w++) {
    b = p;
    points.push(b);
    for (let i = 1; i < pwindowSize; i++) {
      b = b.add(p);
      points.push(b);
    }
    p = b.double();
  }
  return points;
};
var Gpows = void 0;
var ctneg = (cnd, p) => {
  const n = p.negate();
  return cnd ? n : p;
};
var wNAF = (n) => {
  const comp = Gpows || (Gpows = precompute());
  let p = I;
  let f = G;
  const pow_2_w = 2 ** W;
  const maxNum = pow_2_w;
  const mask = big(pow_2_w - 1);
  const shiftBy = big(W);
  for (let w = 0; w < pwindows; w++) {
    let wbits = Number(n & mask);
    n >>= shiftBy;
    if (wbits > pwindowSize) {
      wbits -= maxNum;
      n += 1n;
    }
    const off = w * pwindowSize;
    const offF = off;
    const offP = off + Math.abs(wbits) - 1;
    const isEven = w % 2 !== 0;
    const isNeg = wbits < 0;
    if (wbits === 0) {
      f = f.add(ctneg(isEven, comp[offF]));
    } else {
      p = p.add(ctneg(isNeg, comp[offP]));
    }
  }
  return { p, f };
};

// src/crypto.ts
var STORAGE_KEY = "pressprotocol_burner_identity";
async function getOrCreateBurnerIdentity() {
  return new Promise((resolve) => {
    chrome.storage.local.get([STORAGE_KEY], async (result) => {
      const stored = result[STORAGE_KEY];
      if (stored && stored.publicKey && stored.privateKey) {
        resolve(stored);
        return;
      }
      const fresh = await createFreshBurnerIdentity();
      resolve(fresh);
    });
  });
}
async function createFreshBurnerIdentity() {
  const privKeyBytes = utils.randomPrivateKey();
  const pubKeyBytes = await getPublicKeyAsync(privKeyBytes);
  const privateKey = etc.bytesToHex(privKeyBytes);
  const publicKey = etc.bytesToHex(pubKeyBytes);
  const pseudonym = `Anon-${publicKey.slice(0, 4)}...${publicKey.slice(-4)}`;
  const identity = {
    publicKey,
    privateKey,
    pseudonym,
    createdAt: Date.now()
  };
  await new Promise((resolve) => {
    chrome.storage.local.set({ [STORAGE_KEY]: identity }, () => resolve());
  });
  return identity;
}
async function burnCurrentIdentity() {
  await new Promise((resolve) => {
    chrome.storage.local.remove([STORAGE_KEY], () => resolve());
  });
  return createFreshBurnerIdentity();
}

// src/popup.ts
var activeTabId = null;
var activeTabUrl = "";
var activeTabTitle = "";
var currentIdentity = null;
var currentSettings = {
  apiUrl: "http://localhost:4000",
  webAppUrl: "https://pressprotocol.com",
  autoCopyPermalink: true,
  signWithBurnerKey: true
};
var headerPseudonym = document.getElementById("headerPseudonym");
var tabButtons = document.querySelectorAll(".tab-btn");
var tabPanes = document.querySelectorAll(".tab-pane");
var readerBanner = document.getElementById("readerBanner");
var readerTitle = document.getElementById("readerTitle");
var readerCid = document.getElementById("readerCid");
var mirrorsList = document.getElementById("mirrorsList");
var targetDomain = document.getElementById("targetDomain");
var targetTitle = document.getElementById("targetTitle");
var targetAuthor = document.getElementById("targetAuthor");
var targetReadTime = document.getElementById("targetReadTime");
var btnClipNow = document.getElementById("btnClipNow");
var clipProgressCard = document.getElementById("clipProgressCard");
var clipSuccessCard = document.getElementById("clipSuccessCard");
var stepExtract = document.getElementById("stepExtract");
var stepScrub = document.getElementById("stepScrub");
var stepSign = document.getElementById("stepSign");
var stepBroadcast = document.getElementById("stepBroadcast");
var publishedCid = document.getElementById("publishedCid");
var btnCopyCid = document.getElementById("btnCopyCid");
var btnOpenReader = document.getElementById("btnOpenReader");
var btnCopyEmbedCode = document.getElementById("btnCopyEmbedCode");
var scrapsCountBadge = document.getElementById("scrapsCountBadge");
var scrapsEmpty = document.getElementById("scrapsEmpty");
var scrapsList = document.getElementById("scrapsList");
var vaultFooter = document.getElementById("vaultFooter");
var btnClearScraps = document.getElementById("btnClearScraps");
var btnSendToWriter = document.getElementById("btnSendToWriter");
var settingsPseudonym = document.getElementById("settingsPseudonym");
var settingsPubKey = document.getElementById("settingsPubKey");
var btnCopyPubKey = document.getElementById("btnCopyPubKey");
var btnBurnIdentity = document.getElementById("btnBurnIdentity");
var inputApiUrl = document.getElementById("inputApiUrl");
var inputWebAppUrl = document.getElementById("inputWebAppUrl");
var btnSaveSettings = document.getElementById("btnSaveSettings");
var settingsSavedToast = document.getElementById("settingsSavedToast");
function timeAgo(timestamp) {
  const diff = Math.floor((Date.now() - timestamp) / 1e3);
  if (diff < 60) return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}
async function init() {
  setupTabs();
  await loadSettings();
  await loadIdentity();
  await loadScraps();
  await inspectActiveTab();
}
function setupTabs() {
  tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetId = btn.dataset.tab;
      if (!targetId) return;
      tabButtons.forEach((b) => b.classList.remove("active"));
      tabPanes.forEach((pane) => pane.classList.remove("active"));
      btn.classList.add("active");
      const targetPane = document.getElementById(targetId);
      if (targetPane) {
        targetPane.classList.add("active");
      }
      if (targetId === "tabScraps") {
        loadScraps();
      }
    });
  });
}
async function loadSettings() {
  const res = await chrome.runtime.sendMessage({ action: "getSettings" });
  if (res?.success && res.data) {
    currentSettings = res.data;
    inputApiUrl.value = currentSettings.apiUrl || "http://localhost:4000";
    inputWebAppUrl.value = currentSettings.webAppUrl || "https://pressprotocol.com";
  }
}
async function loadIdentity() {
  currentIdentity = await getOrCreateBurnerIdentity();
  headerPseudonym.textContent = currentIdentity.pseudonym;
  settingsPseudonym.textContent = currentIdentity.pseudonym;
  settingsPubKey.textContent = `${currentIdentity.publicKey.slice(0, 14)}...${currentIdentity.publicKey.slice(-10)}`;
}
var preloadedArticle = null;
async function inspectActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return;
  activeTabId = tab.id;
  activeTabUrl = tab.url || "";
  activeTabTitle = tab.title || "Web Page";
  try {
    const urlObj = new URL(activeTabUrl);
    targetDomain.textContent = urlObj.hostname.replace("www.", "");
  } catch {
    targetDomain.textContent = "web-document";
  }
  targetTitle.textContent = activeTabTitle;
  const readerMatch = activeTabUrl.match(/\/read\/([^\/\?#]+)/);
  if (readerMatch) {
    const cid = readerMatch[1];
    displayReaderDiagnostics(cid);
  } else {
    readerBanner.classList.add("hidden");
  }
  try {
    const [result] = await chrome.scripting.executeScript({
      target: { tabId: activeTabId },
      func: extractPageContent
    });
    if (result?.result && typeof result.result === "object") {
      preloadedArticle = result.result;
      if (preloadedArticle.title) {
        targetTitle.textContent = preloadedArticle.title;
      }
      targetAuthor.textContent = preloadedArticle.author ? `By ${preloadedArticle.author}` : "By Sovereign Author";
      targetReadTime.textContent = `~${preloadedArticle.readingTimeMinutes || 1} min read (${preloadedArticle.wordCount || 0} words)`;
    }
  } catch (inspectErr) {
  }
}
async function displayReaderDiagnostics(cid) {
  readerBanner.classList.remove("hidden");
  readerCid.textContent = cid;
  readerTitle.textContent = activeTabTitle.replace(" - PressProtocol", "");
  mirrorsList.innerHTML = `
    <div class="mirror-row">
      <span class="mirror-tag">\u{1F4E6} IPFS Swarm</span>
      <span class="mirror-latency online">\u2713 38ms</span>
    </div>
    <div class="mirror-row">
      <span class="mirror-tag">\u{1F9C5} Tor v3 Onion</span>
      <span class="mirror-latency online">\u2713 210ms</span>
    </div>
    <div class="mirror-row">
      <span class="mirror-tag">\u{1F310} Global CDN Gateway</span>
      <span class="mirror-latency online">\u2713 52ms</span>
    </div>
  `;
  try {
    const res = await chrome.runtime.sendMessage({ action: "checkMirrors", cid });
    if (res?.success && res.data?.mirrors) {
      const mirrors = res.data.mirrors;
      mirrorsList.innerHTML = Object.entries(mirrors).map(([type, m]) => `
          <div class="mirror-row">
            <span class="mirror-tag">${type === "ipfs" ? "\u{1F4E6} IPFS" : type === "tor" ? "\u{1F9C5} Tor" : "\u{1F310} Gateway"}</span>
            <span class="mirror-latency ${m.available ? "online" : "offline"}">
              ${m.available ? `\u2713 ${m.latency || 45}ms` : "\u2717 Unavailable"}
            </span>
          </div>
        `).join("");
    }
  } catch {
  }
}
btnClipNow.addEventListener("click", async () => {
  if (!activeTabId) return;
  btnClipNow.disabled = true;
  clipProgressCard.classList.remove("hidden");
  clipSuccessCard.classList.add("hidden");
  updateStep(stepExtract, "active");
  updateStep(stepScrub, "pending");
  updateStep(stepSign, "pending");
  updateStep(stepBroadcast, "pending");
  let clipped;
  if (preloadedArticle && preloadedArticle.textContent) {
    clipped = preloadedArticle;
  } else {
    try {
      const [result] = await chrome.scripting.executeScript({
        target: { tabId: activeTabId },
        func: extractPageContent
      });
      if (!result || !result.result || typeof result.result !== "object") {
        throw new Error("Could not extract readable article content from this tab.");
      }
      clipped = result.result;
    } catch (err2) {
      console.error("Extraction error:", err2);
      alert(`Could not extract article from this page: ${err2.message || String(err2)}`);
      btnClipNow.disabled = false;
      clipProgressCard.classList.add("hidden");
      return;
    }
  }
  const stepExtractText = stepExtract.querySelector(".step-text");
  if (stepExtractText) {
    stepExtractText.textContent = `Extracted ${clipped.wordCount} words (${Math.round(clipped.telemetry.cleanedByteSize / 1024)} KB)`;
  }
  updateStep(stepExtract, "completed");
  updateStep(stepScrub, "active");
  targetAuthor.textContent = clipped?.author ? `By ${clipped.author}` : "By Sovereign Author";
  targetReadTime.textContent = `~${clipped?.readingTimeMinutes || 1} min read (${clipped?.wordCount || 0} words)`;
  targetTitle.textContent = clipped?.title || activeTabTitle;
  const stepScrubText = stepScrub.querySelector(".step-text");
  if (stepScrubText) {
    stepScrubText.textContent = `Purged ${clipped.telemetry.totalPurged} surveillance beacons & modals`;
  }
  await new Promise((r) => setTimeout(r, 200));
  updateStep(stepScrub, "completed");
  updateStep(stepSign, "active");
  const stepSignText = stepSign.querySelector(".step-text");
  if (stepSignText) {
    stepSignText.textContent = `Signed with Ed25519 key (${currentIdentity?.pseudonym || "Anon"})`;
  }
  await new Promise((r) => setTimeout(r, 200));
  updateStep(stepSign, "completed");
  updateStep(stepBroadcast, "active");
  try {
    const res = await chrome.runtime.sendMessage({
      action: "publishClippedArticle",
      article: clipped
    });
    if (!res.success) {
      throw new Error(res.error || "Gateway error");
    }
    const data = res.data;
    updateStep(stepBroadcast, "completed");
    setTimeout(() => {
      clipProgressCard.classList.add("hidden");
      clipSuccessCard.classList.remove("hidden");
      btnClipNow.disabled = false;
      publishedCid.textContent = data.cid;
      const readUrl = `${currentSettings.webAppUrl}/read/${data.cid}`;
      btnOpenReader.href = readUrl;
      navigator.clipboard.writeText(readUrl).catch(() => {
      });
      const embedCode = `<iframe src="${currentSettings.webAppUrl}/embed/${data.cid}?theme=cyber" width="100%" height="600" frameborder="0" loading="lazy" sandbox="allow-scripts allow-same-origin allow-popups"></iframe>`;
      btnCopyEmbedCode.onclick = () => {
        navigator.clipboard.writeText(embedCode);
        btnCopyEmbedCode.textContent = "\u2713 Embed Code Copied!";
        setTimeout(() => {
          btnCopyEmbedCode.textContent = "</> Copy Embed Code";
        }, 2e3);
      };
    }, 400);
  } catch (err2) {
    console.error("Publishing error:", err2);
    alert(`Failed to syndicate article to PressProtocol gateway: ${err2.message}`);
    btnClipNow.disabled = false;
    clipProgressCard.classList.add("hidden");
  }
});
function updateStep(el, state) {
  el.classList.remove("active", "completed");
  if (state !== "pending") {
    el.classList.add(state);
  }
}
btnCopyCid.addEventListener("click", () => {
  const cid = publishedCid.textContent || "";
  navigator.clipboard.writeText(cid);
  btnCopyCid.textContent = "\u2713";
  setTimeout(() => btnCopyCid.textContent = "\u{1F4CB}", 1800);
});
async function loadScraps() {
  const res = await chrome.runtime.sendMessage({ action: "getScraps" });
  const scraps = res?.success ? res.data : [];
  scrapsCountBadge.textContent = String(scraps.length);
  if (scraps.length === 0) {
    scrapsEmpty.classList.remove("hidden");
    scrapsList.innerHTML = "";
    vaultFooter.classList.add("hidden");
    return;
  }
  scrapsEmpty.classList.add("hidden");
  vaultFooter.classList.remove("hidden");
  scrapsList.innerHTML = scraps.map((scrap) => {
    let hostname = "";
    try {
      hostname = new URL(scrap.url).hostname.replace("www.", "");
    } catch {
      hostname = "link";
    }
    return `
        <div class="scrap-card" data-id="${scrap.id}">
          <div class="scrap-quote">"${escapeHtml(scrap.quote)}"</div>
          <div class="scrap-meta">
            <a href="${scrap.url}" target="_blank" class="scrap-source text-truncate" title="${escapeHtml(scrap.pageTitle)}">
              \u{1F517} ${hostname}
            </a>
            <span>${timeAgo(scrap.timestamp)}</span>
          </div>
          <div class="scrap-actions">
            <button class="btn-scrap-action btn-copy-scrap" data-quote="${escapeAttr(scrap.quote)}" data-title="${escapeAttr(scrap.pageTitle)}" data-url="${escapeAttr(scrap.url)}">
              \u{1F4CB} Copy Markdown
            </button>
            <button class="btn-scrap-action btn-delete-scrap" data-id="${scrap.id}">
              \u{1F5D1}\uFE0F Remove
            </button>
          </div>
        </div>
      `;
  }).join("");
  document.querySelectorAll(".btn-delete-scrap").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.id;
      if (!id) return;
      await chrome.runtime.sendMessage({ action: "deleteScrap", id });
      loadScraps();
    });
  });
  document.querySelectorAll(".btn-copy-scrap").forEach((btn) => {
    btn.addEventListener("click", () => {
      const q = btn.dataset.quote || "";
      const t = btn.dataset.title || "";
      const u = btn.dataset.url || "";
      const markdown = `> "${q}"
>
> \u2014 [${t}](${u})`;
      navigator.clipboard.writeText(markdown);
      btn.textContent = "\u2713 Copied!";
      setTimeout(() => btn.textContent = "\u{1F4CB} Copy Markdown", 1800);
    });
  });
}
btnClearScraps.addEventListener("click", async () => {
  if (confirm("Permanently clear all saved passage scraps?")) {
    await chrome.runtime.sendMessage({ action: "clearScraps" });
    loadScraps();
  }
});
btnSendToWriter.addEventListener("click", async () => {
  const res = await chrome.runtime.sendMessage({ action: "getScraps" });
  const scraps = res?.success ? res.data : [];
  if (scraps.length === 0) return;
  const citationsMarkdown = scraps.map((s) => `> "${s.quote}"
>
> \u2014 [${s.pageTitle}](${s.url})
`).join("\n---\n\n");
  const fullPayload = `# Research Citations (${(/* @__PURE__ */ new Date()).toLocaleDateString()})

${citationsMarkdown}`;
  await navigator.clipboard.writeText(fullPayload);
  chrome.tabs.create({ url: `${currentSettings.webAppUrl}/write` });
});
btnBurnIdentity.addEventListener("click", async () => {
  if (confirm("Burn current Ed25519 identity and provision a fresh sovereign cryptographic keypair?")) {
    currentIdentity = await burnCurrentIdentity();
    await loadIdentity();
    alert("New Ed25519 sovereign burner identity generated.");
  }
});
btnCopyPubKey.addEventListener("click", () => {
  if (currentIdentity) {
    navigator.clipboard.writeText(currentIdentity.publicKey);
    btnCopyPubKey.textContent = "\u2713";
    setTimeout(() => btnCopyPubKey.textContent = "Copy", 1800);
  }
});
btnSaveSettings.addEventListener("click", async () => {
  currentSettings.apiUrl = inputApiUrl.value.trim() || "http://localhost:4000";
  currentSettings.webAppUrl = inputWebAppUrl.value.trim() || "https://pressprotocol.com";
  await chrome.runtime.sendMessage({
    action: "saveSettings",
    settings: currentSettings
  });
  settingsSavedToast.classList.remove("hidden");
  setTimeout(() => {
    settingsSavedToast.classList.add("hidden");
  }, 2200);
});
function escapeHtml(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
function escapeAttr(str) {
  return escapeHtml(str).replace(/"/g, "&quot;");
}
document.addEventListener("DOMContentLoaded", init);
/*! Bundled license information:

@noble/ed25519/index.js:
  (*! noble-ed25519 - MIT License (c) 2019 Paul Miller (paulmillr.com) *)
*/
