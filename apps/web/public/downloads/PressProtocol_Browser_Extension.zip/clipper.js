// src/clipper.ts
var TRACKING_URL_PARAMS = [
  "utm_source",
  "utm_medium",
  "utm_campaign",
  "utm_term",
  "utm_content",
  "utm_id",
  "fbclid",
  "gclid",
  "gclsrc",
  "dclid",
  "msclkid",
  "twclid",
  "ttclid",
  "mc_cid",
  "mc_eid",
  "si",
  "ref",
  "ref_src",
  "ref_url",
  "_hsenc",
  "_hsmi",
  "wickedid",
  "igshid",
  "srsltid",
  "yclid"
];
var KNOWN_TRACKER_DOMAINS = [
  "google-analytics.com",
  "googletagmanager.com",
  "doubleclick.net",
  "facebook.com/tr",
  "facebook.net",
  "connect.facebook.net",
  "pixel.facebook.com",
  "analytics.twitter.com",
  "segment.com",
  "segment.io",
  "hotjar.com",
  "datadoghq-browser-agent.com",
  "criteo.com",
  "taboola.com",
  "outbrain.com",
  "clarity.ms",
  "mixpanel.com",
  "amplitude.com",
  "scorecardresearch.com",
  "quantserve.com",
  "chartbeat.com",
  "parsely.com",
  "crazyegg.com",
  "intercom.io",
  "hubspot.com"
];
function sanitizeUrl(urlStr, base = window.location.href) {
  if (!urlStr || urlStr.startsWith("#") || urlStr.startsWith("mailto:") || urlStr.startsWith("tel:")) {
    return { cleanedUrl: urlStr || "", purged: 0 };
  }
  try {
    const url = new URL(urlStr, base);
    let purged = 0;
    for (const param of TRACKING_URL_PARAMS) {
      if (url.searchParams.has(param)) {
        url.searchParams.delete(param);
        purged++;
      }
    }
    const allKeys = Array.from(url.searchParams.keys());
    for (const key of allKeys) {
      if (key.startsWith("utm_") || key.startsWith("track_") || key.startsWith("analytics_")) {
        url.searchParams.delete(key);
        purged++;
      }
    }
    return { cleanedUrl: url.toString(), purged };
  } catch {
    return { cleanedUrl: urlStr, purged: 0 };
  }
}
function extractPageContent() {
  const originalHtml = document.body ? document.body.innerHTML : "";
  const originalByteSize = new Blob([originalHtml]).size;
  let scriptsPurged = 0;
  let trackingPixelsPurged = 0;
  let trackingParamsPurged = 0;
  let inlineHandlersPurged = 0;
  let surveillanceElementsPurged = 0;
  const purgedTrackersSummary = [];
  const ogTitle = document.querySelector('meta[property="og:title"]')?.getAttribute("content");
  const twitterTitle = document.querySelector('meta[name="twitter:title"]')?.getAttribute("content");
  const h1Text = document.querySelector("h1")?.textContent?.trim();
  const rawTitle = ogTitle || twitterTitle || h1Text || document.title || "Untitled Article";
  const title = rawTitle.replace(/\s*[|\-–—]\s*[^|\-–—]+$/, "").trim();
  const ogAuthor = document.querySelector('meta[name="author"]')?.getAttribute("content") || document.querySelector('meta[property="article:author"]')?.getAttribute("content") || document.querySelector('meta[name="twitter:creator"]')?.getAttribute("content") || document.querySelector('[rel="author"]')?.textContent?.trim() || document.querySelector(".byline, .author-name, .author, .post-author")?.textContent?.trim() || "";
  const author = ogAuthor.replace(/^by\s+/i, "").trim() || window.location.hostname.replace("www.", "");
  const ogDesc = document.querySelector('meta[property="og:description"]')?.getAttribute("content") || document.querySelector('meta[name="description"]')?.getAttribute("content") || document.querySelector('meta[name="twitter:description"]')?.getAttribute("content") || "";
  const excerpt = ogDesc.trim();
  const canonicalTag = document.querySelector('link[rel="canonical"]')?.getAttribute("href");
  const { cleanedUrl: canonicalUrl } = sanitizeUrl(canonicalTag || window.location.href);
  const pubDate = document.querySelector('meta[property="article:published_time"]')?.getAttribute("content") || document.querySelector("time[datetime]")?.getAttribute("datetime") || document.querySelector("time")?.textContent?.trim() || (/* @__PURE__ */ new Date()).toISOString();
  const siteName = document.querySelector('meta[property="og:site_name"]')?.getAttribute("content") || window.location.hostname.replace("www.", "");
  const metaKeywords = document.querySelector('meta[name="keywords"]')?.getAttribute("content") || "";
  const tags = metaKeywords ? metaKeywords.split(",").map((t) => t.trim()).filter(Boolean) : [];
  document.querySelectorAll('a[href*="/tag/"], a[href*="/category/"], a[href*="/topic/"]').forEach((el) => {
    const text = el.textContent?.replace(/^#/, "").trim();
    if (text && text.length < 25 && !tags.includes(text)) {
      tags.push(text);
    }
  });
  const candidateSelectors = [
    "article",
    '[role="main"]',
    "main",
    ".post-content",
    ".entry-content",
    ".article-body",
    ".article-content",
    ".story-content",
    ".gh-content",
    ".available-content",
    ".markup--post-full",
    ".caas-body",
    "#article-body",
    "#content"
  ];
  let bestContainer = null;
  for (const selector of candidateSelectors) {
    const el = document.querySelector(selector);
    if (el) {
      const pCount = el.querySelectorAll("p").length;
      if (pCount >= 2 || selector === ".available-content" || selector === ".gh-content") {
        bestContainer = el;
        break;
      }
    }
  }
  const sourceNode = bestContainer || document.body;
  const clone = sourceNode.cloneNode(true);
  const removeElements = (selector, reason) => {
    clone.querySelectorAll(selector).forEach((el) => {
      el.remove();
      surveillanceElementsPurged++;
      if (purgedTrackersSummary.length < 10 && !purgedTrackersSummary.includes(reason)) {
        purgedTrackersSummary.push(reason);
      }
    });
  };
  clone.querySelectorAll("script, noscript, style, link[rel='stylesheet']").forEach((el) => {
    el.remove();
    scriptsPurged++;
  });
  if (scriptsPurged > 0) {
    purgedTrackersSummary.push(`Active Scripts & CSS Overlays (${scriptsPurged})`);
  }
  removeElements("nav, header, footer, aside, form, button, dialog, menu", "Page Nav & Interactive Modals");
  removeElements(
    ".paywall, .subscription-widget-wrap, .newsletter-signup, .pencraft-dialog, .gate-container, [class*='paywall'], [id*='paywall'], [class*='subscribe-gate'], .tp-modal, .fc-ab-root",
    "Paywall & Subscription Gate Overlays"
  );
  removeElements(
    ".ad, .ads, .advertisement, .ad-banner, [id*='google_ads'], [class*='taboola'], [class*='outbrain'], .sponsored, .outbrain, .taboola",
    "Third-Party Ad Networks & Sponsored Links"
  );
  removeElements(".share-dialog, .post-ufi, .like-button, .clap-button, .social-share, .comments, #comments", "Social Tracking Widgets");
  clone.querySelectorAll("iframe, object, embed").forEach((frame) => {
    const src = frame.getAttribute("src") || "";
    const isSafe = src.includes("youtube.com") || src.includes("youtube-nocookie.com") || src.includes("vimeo.com");
    if (!isSafe) {
      frame.remove();
      surveillanceElementsPurged++;
      if (!purgedTrackersSummary.includes("Tracking iFrames")) {
        purgedTrackersSummary.push("Tracking iFrames");
      }
    }
  });
  clone.querySelectorAll("img").forEach((img) => {
    const src = img.getAttribute("src") || "";
    const width = parseInt(img.getAttribute("width") || "100", 10);
    const height = parseInt(img.getAttribute("height") || "100", 10);
    const style = img.getAttribute("style") || "";
    const isPixel = width <= 1 || height <= 1 || style.includes("display:none") || style.includes("visibility:hidden");
    const isTrackerDomain = KNOWN_TRACKER_DOMAINS.some((domain) => src.includes(domain));
    const isBeacon = /\/(tr|collect|pixel|beacon|telemetry|track|event)\b/i.test(src);
    if (isPixel || isTrackerDomain || isBeacon) {
      img.remove();
      trackingPixelsPurged++;
      if (!purgedTrackersSummary.includes("Invisible Tracking Pixels")) {
        purgedTrackersSummary.push("Invisible Tracking Pixels");
      }
    } else {
      const { cleanedUrl, purged } = sanitizeUrl(src);
      img.setAttribute("src", cleanedUrl);
      trackingParamsPurged += purged;
      img.setAttribute("loading", "lazy");
      img.setAttribute("decoding", "async");
      img.removeAttribute("srcset");
    }
  });
  const allElements = clone.querySelectorAll("*");
  allElements.forEach((el) => {
    const attrs = Array.from(el.attributes);
    for (const attr of attrs) {
      const name = attr.name.toLowerCase();
      if (name.startsWith("on")) {
        el.removeAttribute(attr.name);
        inlineHandlersPurged++;
      } else if (name.startsWith("data-track") || name.startsWith("data-analytics") || name.startsWith("data-ga") || name.startsWith("data-amplitude") || name === "ping") {
        el.removeAttribute(attr.name);
        surveillanceElementsPurged++;
      }
    }
  });
  clone.querySelectorAll("a").forEach((a) => {
    const href = a.getAttribute("href") || "";
    if (href) {
      const { cleanedUrl, purged } = sanitizeUrl(href);
      a.setAttribute("href", cleanedUrl);
      trackingParamsPurged += purged;
      a.setAttribute("rel", "noopener noreferrer");
      a.setAttribute("target", "_blank");
    }
  });
  const textContent = (clone.textContent || "").replace(/\s+/g, " ").trim();
  const wordCount = textContent ? textContent.split(/\s+/).length : 0;
  const readingTimeMinutes = Math.max(1, Math.ceil(wordCount / 200));
  const contentHtml = clone.innerHTML.trim();
  const cleanedByteSize = new Blob([contentHtml]).size;
  const totalPurged = scriptsPurged + trackingPixelsPurged + trackingParamsPurged + inlineHandlersPurged + surveillanceElementsPurged;
  const telemetry = {
    scriptsPurged,
    trackingPixelsPurged,
    trackingParamsPurged,
    inlineHandlersPurged,
    surveillanceElementsPurged,
    totalPurged,
    originalByteSize,
    cleanedByteSize,
    wordCount,
    readingTimeMinutes,
    purgedTrackersSummary
  };
  return {
    title,
    author,
    excerpt,
    contentHtml,
    textContent,
    canonicalUrl,
    publishedAt: pubDate,
    siteName,
    tags: tags.slice(0, 6),
    wordCount,
    readingTimeMinutes,
    telemetry
  };
}
export {
  extractPageContent,
  sanitizeUrl
};
