"use strict";
(() => {
  // src/content.ts
  document.addEventListener(
    "click",
    (event) => {
      const target = event.target;
      if (!target) return;
      const anchor = target.closest("a");
      if (!anchor) return;
      const href = anchor.getAttribute("href") || anchor.href || "";
      if (href.startsWith("pressprotocol://") || href.startsWith("anonpress://")) {
        event.preventDefault();
        event.stopPropagation();
        const rawCid = href.replace(/^(pressprotocol|anonpress):\/\//, "").replace(/^\/+/, "");
        if (rawCid) {
          chrome.runtime.sendMessage({
            action: "openProtocolLink",
            cid: rawCid
          });
        }
      }
    },
    true
    // Capture phase to intercept before page listeners or browser navigation
  );
})();
